package s373.flob;

public class pt2{
	public int x; 
	public int y; 
	pt2(){}
	pt2(int x,int y) {this.x=x; this.y=y; }
}